# Remove WordPress Comments
This plugin removes all traces of the comments functionality from WordPress.